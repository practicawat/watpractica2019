﻿using DiceGame.PlayerSpace;
using Microsoft.EntityFrameworkCore;

namespace DiceGame.DiceDBContext
{
    public class DiceGameDBContext : DbContext
    {
        public DbSet<Player> Players {get; set;}
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer(
                @"Server=(localdb)\mssqllocaldb;Database=DiceGame;Integrated Security=True");
        }

    }
}
