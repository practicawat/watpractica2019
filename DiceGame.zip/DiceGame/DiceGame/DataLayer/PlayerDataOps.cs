﻿using System;
using System.Collections.Generic;
using System.Text;
using DiceGame.DiceDBContext;
using DiceGame.PlayerSpace;
using System.Linq;


namespace DiceGame.DataLayer
{
    public class PlayerDataOps
    {
        private readonly DiceGameDBContext dataContext;
        public PlayerDataOps()
        {
            this.dataContext = new DiceGameDBContext();
        }
        public Player[] GetPlayers()
        {
            return dataContext.Players.ToArray();
        }
        public Player GetPlayerByName(string playerName)
        {
            return dataContext.Players.SingleOrDefault(x => x.Name == playerName);
        }
        public void AddPlayer(Player newPlayer)
        {

            try
            {
                dataContext.Players.Add(newPlayer);
                dataContext.SaveChanges();
            }
            catch (Exception ex)
            {

                Console.WriteLine("Exception occured in adding player: " + ex.Message); 
            }
        }
        public void DeletePLayer(Player playerToDelete)
        {
            try
            {
                dataContext.Players.Remove(playerToDelete);
                dataContext.SaveChanges();
            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception occured in deleting player: "+ex.Message);
                
            }
        }
        public void UpdatePlayer(Player playerToUpdate)
        {
            try
            {
                dataContext.Players.Update(playerToUpdate);
                dataContext.SaveChanges();
            }
            catch(Exception ex)
            {
                Console.WriteLine("Exception occured in updating player: " + ex.Message);
            }
        }
    }
}
