﻿using  DiceGame.PlayerSpace;
using System.Collections.Generic;

namespace DiceGame.Game
{
    interface IGame
    {
        List<Player> PlayerList { get; set; }
        Player PlayGame();

    }
}
