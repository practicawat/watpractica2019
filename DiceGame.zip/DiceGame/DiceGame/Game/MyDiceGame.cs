﻿using DiceGame.PlayerSpace;
using System.Collections.Generic;
using System.Linq;
using System;

namespace DiceGame.Game
{
    public class MyDiceGame : IGame
    {
        public List<Player> PlayerList { get;set; }
        const int numberOfDices = 2;
        private readonly List<Dice> DiceList;
        readonly Dictionary<Player, int> results;

        public MyDiceGame(List<Player> players)
        {
            this.PlayerList = players;
            results = new Dictionary<Player, int>();
            foreach(Player player in PlayerList)
            {
                results.Add(player, 0);
            }
            DiceList = new List<Dice>();
            for(int i=0;i<numberOfDices;i++)
            {
                DiceList.Add(new Dice(6));
            }

        }
        public Player PlayGame()
        {
            
            int maxValue = 0;
            while(results.Count(x => x.Value == maxValue)>1)
            {
                foreach (Player player in PlayerList)
                {
                    int sum = 0;
                    foreach (Dice dice in DiceList)
                    {
                        int rolled = dice.RollTheDice();
                        Console.WriteLine(player.Name + "rolled " + rolled.ToString());
                        sum += rolled;

                    }
                    Console.WriteLine(player.Name + "'s sum is " + sum.ToString());
                    results[player] = sum;
                }
                maxValue = results.Max(x => x.Value);

                
            }
            return results.SingleOrDefault(x => x.Value == maxValue).Key;

        }
    }
}
