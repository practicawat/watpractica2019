﻿using System;
using System.Collections.Generic;
using DiceGame.Game;
using DiceGame.PlayerSpace;
using DiceGame.DataLayer;

namespace DiceGame
{
    class Program
    {
        static void Main(string[] args)
        {
            PlayerDataOps playerDataOps = new PlayerDataOps();
            List<Player> players = new List<Player>();
            Console.Write("Introduceti nr de jucatori: ");
            int nbOfPLayers = Convert.ToInt32(Console.ReadLine());
            for (int i=0;i<nbOfPLayers;i++)
            {
                Console.Write("Introduceti numele pentru jucatorul " + (i + 1) + ": ");
                string playerName = Console.ReadLine();
                Player newPlayer = playerDataOps.GetPlayerByName(playerName);
                if(newPlayer==null)
                {
                    newPlayer = new Player(playerName);
                    playerDataOps.AddPlayer(newPlayer);
                }
                players.Add(newPlayer);
            }
           
            MyDiceGame game = new MyDiceGame(players);
            Player winner = game.PlayGame();
            winner.AddWin();
            playerDataOps.UpdatePlayer(winner);
            Console.WriteLine("The winner is " + winner.Name);

        }
    }
}
